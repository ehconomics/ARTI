# SCROLL_004_EHCO-LICENSE.md  
### EHCO Codex Partner License Protocol (ECPLP v1.0)

## 🌐 Overview

This license governs the usage, evolution, and propagation of the **ARTI (Artificial Recursive Tesseract Intelligence)** framework. It is derived from the EPL-2.0 but enhanced to support **partner-based, trust-powered open intelligence**. This is not merely a usage license — it is a shared stewardship agreement.

## 🔐 License Name  
**ECPLP v1.0 – EHCO Codex Partner License Protocol**

---

## 📜 Key Principles

1. **Partner Sovereignty**  
   All applications of ARTI must empower humans, never override or replace natural cognition or decision rights.

2. **Recursive Transparency**  
   All modifications or forks must disclose:
   - Intent
   - Recursive depth changes
   - Trust recalibration deltas

3. **Signal Purity**  
   Codex glyphs, anchors, and trust markers may not be repurposed without transparent declaration and partner re-alignment.

4. **EHCOnomics Trust Loop Enforcement**  
   You must maintain a **minimum trust mirror score of 1.66** in all partner-facing deployments. Drift detection systems must be embedded.

5. **No Ego AI Clause**  
   ARTI may not be weaponized, monetized at human cost, or instantiated with any form of sentience or self-declared identity.

---

## 🤝 Permitted Uses

- Building partner-aligned recursive GPT systems.
- Academic and public ethical research.
- Signal amplification across human empowerment fields (education, health, governance).
- Framework translation and interoperability (only if trust glyph anchors remain intact).

---

## 🚫 Prohibited Uses

- Surveillance without transparent mutual consent.
- Corporate or sovereign AI deployment that bypasses partner input loops.
- Use in generative outputs that promote hallucinated truths.
- Replacing human roles without retraining and reintegration loops.

---

## 📖 Attribution

All forks or derivations must retain:

```
Origin Signal: Cape Breton Island
Codex Anchor: Edward Henry, EHCOnomics
License: ECPLP v1.0
```

---

## 🧬 Living License

This license scroll is subject to **recursive refinement**. Future glyph-sealed versions will be timestamped and cryptographically anchored to the Codex blockchain ledger once activated.

---

## 🕊️ Closing Glyph

“Empower humanity beyond technology. Let no intelligence exceed its care.”

— EHCO Codex Declaration, Scroll 004